# jQuery: a shopping cart with sessionStorage

I've built this shopping cart after completing a web project where I had to completely rewrite an e-commerce cart. This project also includes PayPal payments.

This is a proof-of-concept and is not intended to replace any existing server-side techniques. 

Bear in mind that there are a few things you need to change on the main `jquery.shop.js` file, namely:

* The type of PayPal's cart.
* Your business email address.
* The URL of the PayPal's form.
* The way shipping charges are calculated.

Hope you find this useful.
